class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.container.Sequential
  __annotations__["1"] = __torch__.torch.nn.modules.container.___torch_mangle_27.Sequential
  __annotations__["2"] = __torch__.torch.nn.modules.container.___torch_mangle_46.Sequential
class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.conv.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  __annotations__["2"] = __torch__.torch.nn.modules.activation.ReLU
  __annotations__["3"] = __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  __annotations__["4"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm2d
  __annotations__["5"] = __torch__.torch.nn.modules.activation.___torch_mangle_2.ReLU
  __annotations__["6"] = __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  __annotations__["7"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_4.BatchNorm2d
  __annotations__["8"] = __torch__.torch.nn.modules.activation.___torch_mangle_5.ReLU
  __annotations__["9"] = __torch__.torch.nn.modules.conv.___torch_mangle_6.Conv2d
  __annotations__["10"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_7.BatchNorm2d
  __annotations__["11"] = __torch__.torch.nn.modules.activation.___torch_mangle_8.ReLU
  def forward(self: __torch__.torch.nn.modules.container.Sequential,
    argument_1: Tensor) -> Tensor:
    _11 = getattr(self, "11")
    _10 = getattr(self, "10")
    _9 = getattr(self, "9")
    _8 = getattr(self, "8")
    _7 = getattr(self, "7")
    _6 = getattr(self, "6")
    _5 = getattr(self, "5")
    _4 = getattr(self, "4")
    _3 = getattr(self, "3")
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _12 = (_1).forward((_0).forward(argument_1, ), )
    _13 = (_4).forward((_3).forward((_2).forward(_12, ), ), )
    _14 = (_7).forward((_6).forward((_5).forward(_13, ), ), )
    _15 = (_10).forward((_9).forward((_8).forward(_14, ), ), )
    return (_11).forward(_15, )
