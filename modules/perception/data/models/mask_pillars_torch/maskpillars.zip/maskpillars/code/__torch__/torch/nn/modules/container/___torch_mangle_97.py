class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_89.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_90.BatchNorm2d
  __annotations__["2"] = __torch__.torch.nn.modules.activation.___torch_mangle_91.ReLU
  __annotations__["3"] = __torch__.torch.nn.modules.conv.___torch_mangle_92.Conv2d
  __annotations__["4"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_93.BatchNorm2d
  __annotations__["5"] = __torch__.torch.nn.modules.activation.___torch_mangle_94.ReLU
  __annotations__["6"] = __torch__.torch.nn.modules.conv.___torch_mangle_95.Conv2d
  __annotations__["7"] = __torch__.torch.nn.modules.activation.___torch_mangle_96.Sigmoid
