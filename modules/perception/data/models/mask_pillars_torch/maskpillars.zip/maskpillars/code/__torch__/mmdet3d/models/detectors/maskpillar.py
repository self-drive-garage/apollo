class MaskPillar(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  backbone : __torch__.mmdet3d.models.backbones.second_mask.SECONDMASK
  neck : __torch__.mmdet3d.models.necks.second_fpn_mask.SECONDFPNMASK
  bbox_head : __torch__.mmdet3d.models.dense_heads.anchor3d_head.Anchor3DHead
  voxel_layer : __torch__.mmcv.ops.voxelize.Voxelization
  voxel_encoder : __torch__.mmdet3d.models.voxel_encoders.voxel_encoder.HardVFE
  middle_encoder : __torch__.mmdet3d.models.middle_encoders.pillar_scatter.PointPillarsScatter
  def forward(self: __torch__.mmdet3d.models.detectors.maskpillar.MaskPillar,
    voxels: Tensor,
    num_points: Tensor,
    coors: Tensor) -> List[Tensor]:
    bbox_head = self.bbox_head
    conv_dir_cls = bbox_head.conv_dir_cls
    bbox_head0 = self.bbox_head
    conv_reg = bbox_head0.conv_reg
    bbox_head1 = self.bbox_head
    conv_cls = bbox_head1.conv_cls
    neck = self.neck
    deblocks = neck.deblocks
    _2 = getattr(deblocks, "2")
    neck0 = self.neck
    deblocks0 = neck0.deblocks
    _1 = getattr(deblocks0, "1")
    neck1 = self.neck
    deblocks1 = neck1.deblocks
    _0 = getattr(deblocks1, "0")
    backbone = self.backbone
    middle_encoder = self.middle_encoder
    voxel_encoder = self.voxel_encoder
    _3 = (voxel_encoder).forward(voxels, num_points, coors, )
    _4 = torch.select(torch.select(coors, 0, -1), 0, 0)
    batch_size = torch.add(_4, CONSTANTS.c0)
    _5 = (middle_encoder).forward(coors, _3, int(batch_size), )
    _6, _7, _8, = (backbone).forward(_5, )
    _9 = [(_0).forward(_6, ), (_1).forward(_7, ), (_2).forward(_8, )]
    input = torch.cat(_9, 1)
    _10 = torch.permute((conv_cls).forward(input, ), [0, 2, 3, 1])
    _11 = torch.contiguous(_10)
    _12 = torch.permute((conv_reg).forward(input, ), [0, 2, 3, 1])
    _13 = torch.contiguous(_12)
    _14 = torch.permute((conv_dir_cls).forward(input, ), [0, 2, 3, 1])
    return [_11, _13, torch.contiguous(_14)]
