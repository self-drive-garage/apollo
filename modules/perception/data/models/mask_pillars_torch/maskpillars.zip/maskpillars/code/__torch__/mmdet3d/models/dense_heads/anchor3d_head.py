class Anchor3DHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  loss_cls : __torch__.mmdet.models.losses.focal_loss.FocalLoss
  loss_bbox : __torch__.mmdet.models.losses.smooth_l1_loss.SmoothL1Loss
  loss_dir : __torch__.mmdet.models.losses.cross_entropy_loss.CrossEntropyLoss
  conv_cls : __torch__.torch.nn.modules.conv.___torch_mangle_98.Conv2d
  conv_reg : __torch__.torch.nn.modules.conv.___torch_mangle_99.Conv2d
  conv_dir_cls : __torch__.torch.nn.modules.conv.___torch_mangle_100.Conv2d
