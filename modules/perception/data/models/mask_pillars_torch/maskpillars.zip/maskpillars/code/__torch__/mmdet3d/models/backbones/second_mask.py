class SECONDMASK(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  blocks : __torch__.torch.nn.modules.container.ModuleList
  softmasks : __torch__.torch.nn.modules.container.___torch_mangle_76.ModuleList
  def forward(self: __torch__.mmdet3d.models.backbones.second_mask.SECONDMASK,
    argument_1: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    blocks = self.blocks
    _2 = getattr(blocks, "2")
    softmasks = self.softmasks
    _20 = getattr(softmasks, "2")
    blocks0 = self.blocks
    _1 = getattr(blocks0, "1")
    softmasks0 = self.softmasks
    _10 = getattr(softmasks0, "1")
    blocks1 = self.blocks
    _0 = getattr(blocks1, "0")
    softmasks1 = self.softmasks
    _00 = getattr(softmasks1, "0")
    _3 = (_00).forward(argument_1, )
    _4 = (_0).forward(argument_1, )
    input = torch.add(torch.mul(_4, _3), _4)
    _5 = (_10).forward(input, )
    _6 = (_1).forward(input, )
    input0 = torch.add(torch.mul(_6, _5), _6)
    _7 = (_20).forward(input0, )
    _8 = (_2).forward(input0, )
    input1 = torch.add(torch.mul(_8, _7), _8)
    return (input, input0, input1)
