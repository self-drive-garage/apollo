class ZeroPad2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.padding.ZeroPad2d,
    argument_1: Tensor) -> Tensor:
    input = torch.constant_pad_nd(argument_1, [1, 1, 1, 1], 0.)
    return input
