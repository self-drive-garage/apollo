class PointPillarScatter(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.pcdet.models.backbones_2d.map_to_bev.pointpillar_scatter.PointPillarScatter,
    coords: Tensor,
    argument_2: Tensor) -> Tensor:
    spatial_feature = torch.zeros([64, 102400], dtype=6, layout=None, device=torch.device("cuda:0"), pin_memory=False)
    _0 = torch.slice(coords, 0, 0, 9223372036854775807, 1)
    batch_mask = torch.eq(torch.select(_0, 1, 0), 0)
    _1 = torch.slice(coords, 1, 0, 9223372036854775807, 1)
    batch_mask0 = torch.to(batch_mask, dtype=11, layout=0, device=torch.device("cuda:0"), pin_memory=None, non_blocking=False, copy=False, memory_format=None)
    _2 = annotate(List[Optional[Tensor]], [batch_mask0])
    this_coords = torch.index(_1, _2)
    _3 = torch.slice(this_coords, 0, 0, 9223372036854775807, 1)
    _4 = torch.select(_3, 1, 1)
    _5 = torch.slice(this_coords, 0, 0, 9223372036854775807, 1)
    _6 = torch.mul(torch.select(_5, 1, 2), CONSTANTS.c6)
    _7 = torch.add(_4, _6, alpha=1)
    _8 = torch.slice(this_coords, 0, 0, 9223372036854775807, 1)
    indices = torch.add(_7, torch.select(_8, 1, 3), alpha=1)
    indices0 = torch.to(indices, torch.device("cuda:0"), 4, False, False, None)
    _9 = torch.slice(argument_2, 1, 0, 9223372036854775807, 1)
    batch_mask1 = torch.to(batch_mask0, dtype=11, layout=0, device=torch.device("cuda:0"), pin_memory=None, non_blocking=False, copy=False, memory_format=None)
    _10 = annotate(List[Optional[Tensor]], [batch_mask1])
    pillars = torch.index(_9, _10)
    pillars0 = torch.t(pillars)
    _11 = torch.slice(spatial_feature, 0, 0, 9223372036854775807, 1)
    indices1 = torch.to(indices0, dtype=4, layout=0, device=torch.device("cuda:0"), pin_memory=None, non_blocking=False, copy=False, memory_format=None)
    _12 = annotate(List[Optional[Tensor]], [None, indices1])
    _13 = torch.index_put_(_11, _12, pillars0, False)
    batch_spatial_features = torch.stack([spatial_feature], 0)
    input = torch.view(batch_spatial_features, [1, 64, 320, 320])
    return input
