class BaseBEVBackbone(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  blocks : __torch__.torch.nn.modules.container.___torch_mangle_49.ModuleList
  deblocks : __torch__.torch.nn.modules.container.___torch_mangle_61.ModuleList
  def forward(self: __torch__.pcdet.models.backbones_2d.base_bev_backbone.BaseBEVBackbone,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self.deblocks, "2")
    _1 = getattr(self.blocks, "2")
    _2 = getattr(self.deblocks, "1")
    _3 = getattr(self.blocks, "1")
    _4 = getattr(self.deblocks, "0")
    _5 = (getattr(self.blocks, "0")).forward(argument_1, )
    _6 = (_4).forward(_5, )
    _7 = (_3).forward(_5, )
    _8 = [_6, (_2).forward(_7, ), (_0).forward((_1).forward(_7, ), )]
    return torch.cat(_8, 1)
