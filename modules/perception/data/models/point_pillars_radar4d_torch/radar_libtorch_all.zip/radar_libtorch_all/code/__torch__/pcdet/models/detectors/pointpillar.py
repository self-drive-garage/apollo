class PointPillar(Module):
  __parameters__ = []
  __buffers__ = ["global_step", ]
  global_step : Tensor
  training : bool
  vfe : __torch__.pcdet.models.backbones_3d.vfe.pillar_vfe.Radar7PillarVFE
  map_to_bev_module : __torch__.pcdet.models.backbones_2d.map_to_bev.pointpillar_scatter.PointPillarScatter
  backbone_2d : __torch__.pcdet.models.backbones_2d.base_bev_backbone.BaseBEVBackbone
  dense_head : __torch__.pcdet.models.dense_heads.anchor_head_single.AnchorHeadSingle
  def forward(self: __torch__.pcdet.models.detectors.pointpillar.PointPillar,
    voxel_features: Tensor,
    voxel_num_points: Tensor,
    coords: Tensor) -> List[Tensor]:
    _0 = self.dense_head.conv_dir_cls
    _1 = self.dense_head.conv_box
    _2 = self.dense_head.conv_cls
    _3 = self.backbone_2d
    _4 = self.map_to_bev_module
    _5 = (self.vfe).forward(voxel_features, voxel_num_points, coords, )
    _6 = (_3).forward((_4).forward(coords, _5, ), )
    _7 = torch.permute((_2).forward(_6, ), [0, 2, 3, 1])
    _8 = torch.contiguous(_7, memory_format=0)
    _9 = torch.permute((_1).forward(_6, ), [0, 2, 3, 1])
    _10 = torch.contiguous(_9, memory_format=0)
    _11 = torch.permute((_0).forward(_6, ), [0, 2, 3, 1])
    _12 = torch.contiguous(_11, memory_format=0)
    return [_8, _10, _12]
