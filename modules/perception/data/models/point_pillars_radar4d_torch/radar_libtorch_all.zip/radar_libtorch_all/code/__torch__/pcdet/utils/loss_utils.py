class SigmoidFocalClassificationLoss(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
class WeightedSmoothL1Loss(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
class WeightedCrossEntropyLoss(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
