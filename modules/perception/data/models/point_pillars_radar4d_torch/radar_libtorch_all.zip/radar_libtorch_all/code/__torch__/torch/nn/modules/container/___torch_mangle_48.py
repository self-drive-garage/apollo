class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.padding.___torch_mangle_29.ZeroPad2d
  __annotations__["1"] = __torch__.torch.nn.modules.conv.___torch_mangle_30.Conv2d
  __annotations__["2"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_31.BatchNorm2d
  __annotations__["3"] = __torch__.torch.nn.modules.activation.___torch_mangle_32.ReLU
  __annotations__["4"] = __torch__.torch.nn.modules.conv.___torch_mangle_33.Conv2d
  __annotations__["5"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_34.BatchNorm2d
  __annotations__["6"] = __torch__.torch.nn.modules.activation.___torch_mangle_35.ReLU
  __annotations__["7"] = __torch__.torch.nn.modules.conv.___torch_mangle_36.Conv2d
  __annotations__["8"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_37.BatchNorm2d
  __annotations__["9"] = __torch__.torch.nn.modules.activation.___torch_mangle_38.ReLU
  __annotations__["10"] = __torch__.torch.nn.modules.conv.___torch_mangle_39.Conv2d
  __annotations__["11"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_40.BatchNorm2d
  __annotations__["12"] = __torch__.torch.nn.modules.activation.___torch_mangle_41.ReLU
  __annotations__["13"] = __torch__.torch.nn.modules.conv.___torch_mangle_42.Conv2d
  __annotations__["14"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_43.BatchNorm2d
  __annotations__["15"] = __torch__.torch.nn.modules.activation.___torch_mangle_44.ReLU
  __annotations__["16"] = __torch__.torch.nn.modules.conv.___torch_mangle_45.Conv2d
  __annotations__["17"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_46.BatchNorm2d
  __annotations__["18"] = __torch__.torch.nn.modules.activation.___torch_mangle_47.ReLU
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_48.Sequential,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self, "18")
    _1 = getattr(self, "17")
    _2 = getattr(self, "16")
    _3 = getattr(self, "15")
    _4 = getattr(self, "14")
    _5 = getattr(self, "13")
    _6 = getattr(self, "12")
    _7 = getattr(self, "11")
    _8 = getattr(self, "10")
    _9 = getattr(self, "9")
    _10 = getattr(self, "8")
    _11 = getattr(self, "7")
    _12 = getattr(self, "6")
    _13 = getattr(self, "5")
    _14 = getattr(self, "4")
    _15 = getattr(self, "3")
    _16 = getattr(self, "2")
    _17 = getattr(self, "1")
    _18 = (getattr(self, "0")).forward(argument_1, )
    _19 = (_16).forward((_17).forward(_18, ), )
    _20 = (_14).forward((_15).forward(_19, ), )
    _21 = (_12).forward((_13).forward(_20, ), )
    _22 = (_10).forward((_11).forward(_21, ), )
    _23 = (_7).forward((_8).forward((_9).forward(_22, ), ), )
    _24 = (_4).forward((_5).forward((_6).forward(_23, ), ), )
    _25 = (_1).forward((_2).forward((_3).forward(_24, ), ), )
    return (_0).forward(_25, )
