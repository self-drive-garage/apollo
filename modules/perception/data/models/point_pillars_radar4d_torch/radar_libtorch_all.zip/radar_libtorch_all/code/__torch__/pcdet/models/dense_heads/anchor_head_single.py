class AnchorHeadSingle(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  cls_loss_func : __torch__.pcdet.utils.loss_utils.SigmoidFocalClassificationLoss
  reg_loss_func : __torch__.pcdet.utils.loss_utils.WeightedSmoothL1Loss
  dir_loss_func : __torch__.pcdet.utils.loss_utils.WeightedCrossEntropyLoss
  conv_cls : __torch__.torch.nn.modules.conv.___torch_mangle_62.Conv2d
  conv_box : __torch__.torch.nn.modules.conv.___torch_mangle_63.Conv2d
  conv_dir_cls : __torch__.torch.nn.modules.conv.___torch_mangle_64.Conv2d
