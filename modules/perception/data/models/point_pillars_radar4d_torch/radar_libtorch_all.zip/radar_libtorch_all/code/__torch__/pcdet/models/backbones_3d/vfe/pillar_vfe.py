class Radar7PillarVFE(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  pfn_layers : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.pcdet.models.backbones_3d.vfe.pillar_vfe.Radar7PillarVFE,
    voxel_features: Tensor,
    voxel_num_points: Tensor,
    coords: Tensor) -> Tensor:
    _0 = getattr(self.pfn_layers, "0")
    _1 = torch.slice(voxel_features, 0, 0, 9223372036854775807, 1)
    _2 = torch.slice(_1, 1, 0, 9223372036854775807, 1)
    orig_xyz = torch.slice(_2, 2, 0, 3, 1)
    _3 = torch.sum(orig_xyz, [1], True, dtype=None)
    voxel_num_points0 = torch.type_as(voxel_num_points, voxel_features)
    _4 = torch.view(voxel_num_points0, [-1, 1, 1])
    points_mean = torch.div(_3, _4)
    f_cluster = torch.sub(orig_xyz, points_mean, alpha=1)
    f_center = torch.zeros_like(orig_xyz, dtype=6, layout=0, device=torch.device("cuda:0"), pin_memory=False, memory_format=None)
    _5 = torch.slice(voxel_features, 0, 0, 9223372036854775807, 1)
    _6 = torch.slice(_5, 1, 0, 9223372036854775807, 1)
    _7 = torch.select(_6, 2, 0)
    _8 = torch.slice(coords, 0, 0, 9223372036854775807, 1)
    _9 = torch.to(torch.select(_8, 1, 3), 6, False, False, None)
    _10 = torch.mul(torch.unsqueeze(_9, 1), CONSTANTS.c0)
    _11 = torch.add(_10, CONSTANTS.c1, alpha=1)
    _12 = torch.sub(_7, _11, alpha=1)
    _13 = torch.slice(f_center, 0, 0, 9223372036854775807, 1)
    _14 = torch.slice(_13, 1, 0, 9223372036854775807, 1)
    _15 = torch.copy_(torch.select(_14, 2, 0), _12, False)
    _16 = torch.slice(voxel_features, 0, 0, 9223372036854775807, 1)
    _17 = torch.slice(_16, 1, 0, 9223372036854775807, 1)
    _18 = torch.select(_17, 2, 1)
    _19 = torch.slice(coords, 0, 0, 9223372036854775807, 1)
    _20 = torch.to(torch.select(_19, 1, 2), 6, False, False, None)
    _21 = torch.mul(torch.unsqueeze(_20, 1), CONSTANTS.c0)
    _22 = torch.add(_21, CONSTANTS.c2, alpha=1)
    _23 = torch.sub(_18, _22, alpha=1)
    _24 = torch.slice(f_center, 0, 0, 9223372036854775807, 1)
    _25 = torch.slice(_24, 1, 0, 9223372036854775807, 1)
    _26 = torch.copy_(torch.select(_25, 2, 1), _23, False)
    _27 = torch.slice(voxel_features, 0, 0, 9223372036854775807, 1)
    _28 = torch.slice(_27, 1, 0, 9223372036854775807, 1)
    _29 = torch.select(_28, 2, 2)
    _30 = torch.slice(coords, 0, 0, 9223372036854775807, 1)
    _31 = torch.to(torch.select(_30, 1, 1), 6, False, False, None)
    _32 = torch.mul(torch.unsqueeze(_31, 1), CONSTANTS.c3)
    _33 = torch.add(_32, CONSTANTS.c4, alpha=1)
    _34 = torch.sub(_29, _33, alpha=1)
    _35 = torch.slice(f_center, 0, 0, 9223372036854775807, 1)
    _36 = torch.slice(_35, 1, 0, 9223372036854775807, 1)
    _37 = torch.copy_(torch.select(_36, 2, 2), _34, False)
    _38 = torch.slice(voxel_features, 0, 0, 9223372036854775807, 1)
    _39 = torch.slice(_38, 1, 0, 9223372036854775807, 1)
    _40 = torch.to(CONSTANTS.c5, dtype=4, layout=0, device=torch.device("cuda:0"), pin_memory=None, non_blocking=False, copy=False, memory_format=None)
    _41 = annotate(List[Optional[Tensor]], [None, None, _40])
    voxel_features0 = torch.index(_39, _41)
    _42 = [voxel_features0, f_cluster, f_center]
    features = torch.cat(_42, -1)
    max_num = ops.prim.NumToTensor(torch.size(features, 1))
    _43 = annotate(number, max_num)
    actual_num = torch.unsqueeze(voxel_num_points0, 1)
    _44 = torch.arange(_43, dtype=3, layout=0, device=torch.device("cuda:0"), pin_memory=False)
    _45 = torch.view(_44, [1, -1])
    _46 = torch.to(actual_num, 3, False, False, None)
    mask = torch.gt(_46, _45)
    mask0 = torch.type_as(torch.unsqueeze(mask, -1), voxel_features0)
    inputs = torch.mul_(features, mask0)
    pillar_features = torch.squeeze((_0).forward(inputs, ))
    return pillar_features
class PFNLayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  linear : __torch__.torch.nn.modules.linear.Linear
  norm : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  def forward(self: __torch__.pcdet.models.backbones_3d.vfe.pillar_vfe.PFNLayer,
    inputs: Tensor) -> Tensor:
    _47 = self.norm
    input = torch.permute((self.linear).forward(inputs, ), [0, 2, 1])
    input0 = torch.permute((_47).forward(input, ), [0, 2, 1])
    x = torch.relu(input0)
    features, _48 = torch.max(x, 1, True)
    return features
