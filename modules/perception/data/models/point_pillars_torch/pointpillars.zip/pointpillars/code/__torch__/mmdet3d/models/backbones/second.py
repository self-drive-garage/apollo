class SECOND(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  blocks : __torch__.torch.nn.modules.container.___torch_mangle_47.ModuleList
  def forward(self: __torch__.mmdet3d.models.backbones.second.SECOND,
    argument_1: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    blocks = self.blocks
    _2 = getattr(blocks, "2")
    blocks0 = self.blocks
    _1 = getattr(blocks0, "1")
    blocks1 = self.blocks
    _0 = getattr(blocks1, "0")
    _3 = (_0).forward(argument_1, )
    _4 = (_1).forward(_3, )
    return (_3, _4, (_2).forward(_4, ))
