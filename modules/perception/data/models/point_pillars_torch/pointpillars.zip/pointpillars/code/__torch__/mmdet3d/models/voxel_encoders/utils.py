class VFELayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm : __torch__.torch.nn.modules.batchnorm.BatchNorm1d
  linear : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.mmdet3d.models.voxel_encoders.utils.VFELayer,
    inputs: Tensor) -> Tensor:
    norm = self.norm
    linear = self.linear
    _0 = torch.permute((linear).forward(inputs, ), [0, 2, 1])
    input = torch.contiguous(_0)
    _1 = torch.permute((norm).forward(input, ), [0, 2, 1])
    input0 = torch.contiguous(_1)
    pointwise = torch.relu(input0)
    aggregated, _2 = torch.max(pointwise, 1, True)
    return torch.squeeze(aggregated, 1)
