class MVXFasterRCNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  pts_voxel_layer : __torch__.mmcv.ops.voxelize.Voxelization
  pts_voxel_encoder : __torch__.mmdet3d.models.voxel_encoders.voxel_encoder.HardVFE
  pts_middle_encoder : __torch__.mmdet3d.models.middle_encoders.pillar_scatter.PointPillarsScatter
  pts_backbone : __torch__.mmdet3d.models.backbones.second.SECOND
  pts_neck : __torch__.mmdet3d.models.necks.second_fpn.SECONDFPN
  pts_bbox_head : __torch__.mmdet3d.models.dense_heads.anchor3d_head.Anchor3DHead
  def forward(self: __torch__.mmdet3d.models.detectors.mvx_faster_rcnn.MVXFasterRCNN,
    voxels: Tensor,
    num_points: Tensor,
    coors: Tensor) -> List[Tensor]:
    pts_bbox_head = self.pts_bbox_head
    conv_dir_cls = pts_bbox_head.conv_dir_cls
    pts_bbox_head0 = self.pts_bbox_head
    conv_reg = pts_bbox_head0.conv_reg
    pts_bbox_head1 = self.pts_bbox_head
    conv_cls = pts_bbox_head1.conv_cls
    pts_neck = self.pts_neck
    deblocks = pts_neck.deblocks
    _2 = getattr(deblocks, "2")
    pts_neck0 = self.pts_neck
    deblocks0 = pts_neck0.deblocks
    _1 = getattr(deblocks0, "1")
    pts_neck1 = self.pts_neck
    deblocks1 = pts_neck1.deblocks
    _0 = getattr(deblocks1, "0")
    pts_backbone = self.pts_backbone
    pts_middle_encoder = self.pts_middle_encoder
    pts_voxel_encoder = self.pts_voxel_encoder
    _3 = (pts_voxel_encoder).forward(voxels, num_points, coors, )
    _4 = torch.select(torch.select(coors, 0, -1), 0, 0)
    batch_size = torch.add(_4, CONSTANTS.c0)
    _5 = (pts_middle_encoder).forward(coors, _3, int(batch_size), )
    _6, _7, _8, = (pts_backbone).forward(_5, )
    _9 = [(_0).forward(_6, ), (_1).forward(_7, ), (_2).forward(_8, )]
    input = torch.cat(_9, 1)
    _10 = torch.permute((conv_cls).forward(input, ), [0, 2, 3, 1])
    _11 = torch.contiguous(_10)
    _12 = torch.permute((conv_reg).forward(input, ), [0, 2, 3, 1])
    _13 = torch.contiguous(_12)
    _14 = torch.permute((conv_dir_cls).forward(input, ), [0, 2, 3, 1])
    return [_11, _13, torch.contiguous(_14)]
