class PointPillarsScatter(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.mmdet3d.models.middle_encoders.pillar_scatter.PointPillarsScatter,
    coors: Tensor,
    argument_2: Tensor,
    argument_3: int) -> Tensor:
    canvas = torch.zeros([64, 219024], dtype=6, layout=None, device=torch.device("cuda:0"), pin_memory=False)
    _0 = torch.slice(coors, 0, 0, 9223372036854775807)
    batch_mask = torch.eq(torch.select(_0, 1, 0), 0)
    _1 = torch.slice(coors, 1, 0, 9223372036854775807)
    _2 = annotate(List[Optional[Tensor]], [batch_mask])
    this_coors = torch.index(_1, _2)
    _3 = torch.slice(this_coors, 0, 0, 9223372036854775807)
    _4 = torch.mul(torch.select(_3, 1, 2), CONSTANTS.c5)
    _5 = torch.slice(this_coors, 0, 0, 9223372036854775807)
    indices = torch.add(_4, torch.select(_5, 1, 3))
    indices0 = torch.to(indices, torch.device("cuda:0"), 4)
    _6 = torch.slice(argument_2, 1, 0, 9223372036854775807)
    _7 = annotate(List[Optional[Tensor]], [batch_mask])
    voxels = torch.index(_6, _7)
    voxels0 = torch.t(voxels)
    _8 = torch.slice(canvas, 0, 0, 9223372036854775807)
    _9 = annotate(List[Optional[Tensor]], [None, indices0])
    _10 = torch.index_put_(_8, _9, voxels0)
    batch_canvas = torch.stack([canvas])
    input = torch.view(batch_canvas, [argument_3, 64, 468, 468])
    return input
